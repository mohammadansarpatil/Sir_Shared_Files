import { useState } from "react";
import { useParams } from "react-router-dom";
import { useEffect } from "react/cjs/react.development";
import airlineService from "../services/airline.service";



function OwnerPage(){

    const {flightId} = useParams();
    const[flightName, setFlightName] = useState('');
    const[flightFrom, setFlightFrom] = useState('');
    const[flightTo, setFlightTo] = useState('');
    const[totalSeats,setTotalSeats] = useState('');
    const[arrivalDate, setArrivalDate] = useState('');
    const[departureDate, setDepartureDate] = useState('');
    const[arrivalTime, setArrivalTime] = useState('');
    const[departureTime, setDepartureTime] = useState('');
    const[economicPrice, setEconomicPrice] = useState('');
    const[businessPrice, setBusinessPrice] = useState('');
    const[firstClassPrice, setFirstClassPrice] = useState('');
    const[flights , setflights] = useState([])

    const[feedbacks , setFeedbacks] = useState([])

    const[brandName, setBrandName] = useState('');
    const[promotionDescription , setPromotionDescription] =  useState('')
    const[image,setImage] = useState('')


    const addPromo = (e) => {
        e.preventDefault();
        
        const user = {image, brandName, promotionDescription};
        
            airlineService.createPromotion(user)
            .then(response => {
                console.log("Promotion added successfully", response.data);
              //history.push("/login");
                window.alert("Promotion Added")
            })
            .catch(error => {
                console.log('something went wrong', error);
            })
            }


    const init = () => {
    airlineService.getAllFeedback()
      .then(response => {
        console.log('Printing Feedback data', response.data);
        setFeedbacks(response.data);
      })
      .catch(error => {
        console.log('Something went wrong', error);
      }) 
  }

  useEffect(() => {
    init();
  }, []);




    return(
        <div className="container">
            <div className="container">
                <div className="container">
        <div className="container">
            <form>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="flightname"
                        value={flightName}
                        onChange={(e) => setFlightName(e.target.value)}
                        placeholder="ENTER FLIGHT NAME"
                    />

                </div>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="flightfrom"
                        value={flightFrom}
                        onChange={(e) => setFlightFrom(e.target.value)}
                        placeholder="ENTER FLIGHT FROM.."
                    />

                </div>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="flightto"
                        value={flightTo}
                        onChange={(e) => setFlightTo(e.target.value)}
                        placeholder="ENTER FLIGHT TO.."
                    />

                </div>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="totalseats"
                        value={totalSeats}
                        onChange={(e) => setTotalSeats(e.target.value)}
                        placeholder="ENTER TOTAL SEATS IN FLIGHT"
                    />

                </div>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="economicprice"
                        value={economicPrice}
                        onChange={(e) => setEconomicPrice(e.target.value)}
                        placeholder="ENTER ECONOMIC PRICE"
                    />
                </div>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="businessprice"
                        value={businessPrice}
                        onChange={(e) => setBusinessPrice(e.target.value)}
                        placeholder="ENTER BUSINESS PRICE"
                    />
                </div>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="firstclassprice"
                        value={firstClassPrice}
                        onChange={(e) => setFirstClassPrice(e.target.value)}
                        placeholder="ENTER FIRST CLASS PRICE"
                    />
                </div>

                <div className="form-group">
                    <input 
                        type="date" 
                        className="form-control col-4"
                        id="departuredate"
                        value={departureDate}
                        onChange={(e) => setDepartureDate(e.target.value)}
                        placeholder="ENTER DATE OF DEPARTURE"
                    />
                </div>

                <div className="form-group">
                    <input 
                        type="date" 
                        className="form-control col-4"
                        id="arrivalDate"
                        value={arrivalDate}
                        onChange={(e) => setArrivalDate(e.target.value)}
                        placeholder="ENTER DATE OF ARRIVAL"
                    />
                </div>

                <div className="form-group">
                    <input 
                        type="time" 
                        className="form-control col-4"
                        id="departuretime"
                        value={departureTime}
                        step="2"
                        onChange={(e) => setDepartureTime(e.target.value)}
                        placeholder="ENTER TIME OF DEPARTURE"
                    />
                </div>

                <div className="form-group">
                    <input 
                        type="time" 
                        className="form-control col-4"
                        id="arrivaltime"
                        value={arrivalTime}
                        step="2"
                        onChange={(e) => setArrivalTime(e.target.value)}
                        placeholder="ENTER TIME OF ARRIVAL"
                    />
                </div>

                <div >
                    <button  className="btn btn-primary">Save</button>
                </div>
            </form>
            <hr/>
        </div>
        <from>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="image"
                        value={image}
                        onChange={(e) => setImage(e.target.value)}
                        placeholder="PROVIDE BRAND IMAGE URL"
                    />
                </div>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="brandname"
                        value={brandName}
                        onChange={(e) => setBrandName(e.target.value)}
                        placeholder="ENTER BRAND NAME"
                    />
                </div>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="promotiondescription"
                        value={promotionDescription}
                        onChange={(e) => setPromotionDescription(e.target.value)}
                        placeholder="ENTER CONTENT FOR ADVERTISMENT"
                    />
                </div>
                <div >
                      <button onClick={(e)=>addPromo(e)} className="btn btn-primary">
                          Save Promotion</button>
                </div>
        </from>
        </div>
        <table border="2px">
            <thead>
                <tr>
                    <td>
                        FEEDBACK DESCRIPTION
                    </td>
                    <td>
                        RATING
                    </td>
                </tr>
            </thead>
            <tbody>
            {
            feedbacks.map(feedback => (
              <tr key={feedback.feedbackId}>
                <td>{feedback.feedbackDescription}</td>
                <td>{feedback.rating}</td>
                
              </tr>
            ))
          }
                
            </tbody>
        </table>
        </div>
        </div>

    )

}

export default OwnerPage;