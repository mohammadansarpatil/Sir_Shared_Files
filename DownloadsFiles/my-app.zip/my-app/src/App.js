import { BrowserRouter, Switch, Route } from 'react-router-dom';
import EmployeeList from './components/EmployeesList';
import NotFound from './components/NotFound';
import 'bootstrap/dist/css/bootstrap.min.css';
import AddEmployee from './components/AddEmployee';


import HomePage from './components/HomePage'
import LoginPage from './components/LoginPage';
import RegistrationPage from './components/RegistrationPage';
import AdminPage from './components/AdminPage';
import UserPage from './components/UserPage';
import OwnerPage from './components/OwnerPage';
import UpdateOffer from './components/UpdateOffer';
import UpdateFlight from './components/UpdateFlight';
import ForgotPassword from './components/ForgotPassword';
import EndPage from './components/EndPage';




function App() {
  return (
    <BrowserRouter>
      <div>
        <div>
          <Switch>
            <Route exact path="/" component={HomePage} />
            <Route path="/register" component={RegistrationPage}/>
            <Route path="/login" component={LoginPage}/>
            <Route path="/userpage" component={UserPage}/>
            <Route path="/adminpage" component={AdminPage}/>
            <Route path="/ownerpage" component={OwnerPage}/>
            <Route path="/forgotpassword" component={ForgotPassword}/>
            <Route path="/offer/:id" component={UpdateOffer}/>
            <Route path="/flight/:id" component={UpdateFlight}/>
            <Route path="/endpage" component={EndPage}/>

            









            <Route path="/add" component={AddEmployee} />
            <Route path="/employees/edit/:id" component={AddEmployee} />
            <Route path="*" component={NotFound} />
          </Switch>
        </div>
      </div>
    </BrowserRouter>
  );
}


export default App;
