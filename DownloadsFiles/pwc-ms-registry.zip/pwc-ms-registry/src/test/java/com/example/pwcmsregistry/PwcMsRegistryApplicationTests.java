package com.example.pwcmsregistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PwcMsRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
