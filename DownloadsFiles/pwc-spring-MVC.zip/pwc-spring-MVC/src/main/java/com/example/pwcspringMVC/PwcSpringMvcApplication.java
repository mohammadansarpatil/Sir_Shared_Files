package com.example.pwcspringMVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PwcSpringMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(PwcSpringMvcApplication.class, args);
	}

}
